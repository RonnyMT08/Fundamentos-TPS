//gcc juego.c ascension_magios.c utiles.o -o juego -std=c99 -Wall -Wconversion -Werror -lm

#include "ascension_magios.h"
#include "utiles.h"
#include <stdio.h>
#include <stdlib.h> // Para usar rand, limpiar terminal, etc.
#include <time.h>   // Para obtener una semilla desde el reloj

#define MAX_CARACTERES 100

const char HOMERO = 'H';

const char PARED = 'X';
const char CAMINO = '-';
const char VACIO = ' ';

const char RUNA = 'U';
const char ALTAR = 'A';

const char PERGAMINO = 'P';
const char TOTEM = 'T';

const char PIEDRA_CASTIGO = 'R';
const char CATAPULTA = 'F';

const char* MSJ_BIENVENIDA = "--Hola Homero, Bienvenido al juego de ascencion de magios--\n\n";

const char ARRIBA = 'W';
const char ABAJO = 'S';
const char DERECHA = 'D';
const char IZQUIERDA = 'A';

const char ANTORCHA = 'L';
const char HECHIZO_REVELADOR = 'H';

/* 
* Pre condiciones: el numero 'maximo' debe ser mayor al 'minimo'.
* Post condiciones: devuelve un numero de manera aleatorio entre el valor 'minimo' y el 'maximo' valor (inclusive).
*/
int numero_aleatorio(int minimo, int maximo){
    int numero = rand() % (maximo - minimo + 1) + minimo;
    return numero;
}

/* 
* Pre condiciones: - 
* Post condiciones: inicializa los 3 niveles del juego los cuales contienen (paredes, caminos y sus topes).  
*/
void inicializar_estructura(nivel_t* niveles){
    int tope_paredes = 0;
    int tope_caminos = 0; 
    
    for (int i = 0; i < MAX_NIVELES; i++){
        
        niveles[i].tope_paredes = tope_paredes;
        niveles[i].tope_camino = tope_caminos;
        
        int nivel_actual = i+1;
        obtener_mapa(niveles[i].paredes, &niveles[i].tope_paredes, niveles[i].camino, &niveles[i].tope_camino, nivel_actual);
    }
}

/*
* Pre condiciones: 
* Post condiciones: inicializa la posicion(fila, columna) del personaje en la primera posicion(fila, columna) del camino
*/
void inicializar_posicion_personaje(coordenada_t* posicion, int fil_camino, int col_camino){
    (*posicion).fil = fil_camino;
    (*posicion).col = col_camino;
}

/*
* Pre condiciones: -
* Post condiciones: inicializa los datos con los que cuenta el personaje
*/
void inicializar_herramientas_personaje(int* hechizos_reveladores, int* antorchas, bool* antorcha_encendida){
    int cantidad_hechizos = 5;
    int cantidad_antorchas = 5;
    
    (*hechizos_reveladores) = cantidad_hechizos;
    (*antorchas) = cantidad_antorchas;
    (*antorcha_encendida) = false;
}

/*
* Pre condiciones: -
* Post condiciones: inicializa el personaje (posicion inicial, vidas, herramientas)
*/
void inicializar_homero (personaje_t *personaje, coordenada_t posicion){
    int cantidad_vidas = 5;
    (*personaje).vidas_restantes = cantidad_vidas;

    int fil_camino = posicion.fil;
    int col_camino = posicion.col;
    inicializar_posicion_personaje(&(*personaje).posicion, fil_camino, col_camino);
    inicializar_herramientas_personaje(&(*personaje).hechizos_reveladores, &(*personaje).antorchas, &(*personaje).antorcha_encendida);
}

/*
* Pre condiciones: el vector camino debe ser inicializado. fila debe estar entre(0-19), columna debe estar entre (0-29).
* Post condiciones: devuelve true si la fila, columna coincide con una posicion del camino(fila, columna). False en caso contrario
*/
bool es_posicion_camino(coordenada_t camino[], int tope_camino, int fila, int columna){
    bool en_camino = false;
    int posicion_camino = 0;
    while(!en_camino && (posicion_camino < tope_camino)){
        if(camino[posicion_camino].fil == fila && camino[posicion_camino].col == columna){
            en_camino = true;
        } else {
            posicion_camino ++;
        }
    }
    return en_camino;
}

/*
* Pre condiciones: -
* Post condiciones: inicializa la posicion del pergamino para cada uno de los tres niveles.
*/
void inicializar_pergaminos(nivel_t niveles[MAX_NIVELES]){
    // PERGAMINO
    int total_pergaminos = 3;
    
    for (int i = 0; i < total_pergaminos; i++){

        int tope_camino = niveles[i].tope_camino;
        int posicion_pergamino = numero_aleatorio(1, tope_camino-2);

        int fil_pergamino = niveles[i].camino[posicion_pergamino].fil;
        int col_pergamino = niveles[i].camino[posicion_pergamino].col;
        
        while (!es_posicion_camino(niveles[i].camino, tope_camino, fil_pergamino, col_pergamino)){
            posicion_pergamino = numero_aleatorio(1, tope_camino-2);
            
            fil_pergamino = niveles[i].camino[posicion_pergamino].fil;
            col_pergamino = niveles[i].camino[posicion_pergamino].col;
        }

        niveles[i].pergamino.fil = fil_pergamino;
        niveles[i].pergamino.col = col_pergamino;        
    }
}

/*
* Pre condiciones: nivel debe estar inicializado. fila debe estar entre (0-19), columna debe estar entre (0-29). 
* Post condiciones devuelve true si la posicion (fila, columna) de un camino coincide con la posicion fila, columna obtenidos. False en caso contrario. 
*/
bool es_posicion_pergamino(coordenada_t pergamino, int fila, int columna){
    return(fila == pergamino.fil && columna == pergamino.col);
}

/*
* Pre condicones: -
* Post condicioes: Inicializa los 5 totems repatidos aleatoriamente en cada uno de los tres niveles, los totems se encuentran en el camino (excluyendo el inicio, final y la posicion del pergamino).  
*/
void inicializar_herramientas(nivel_t niveles[MAX_NIVELES]){
   
   //totem(5 repartidos de manera aleatoria en cada nivel) en el camino
    int tope_niveles = MAX_NIVELES;

    for (int i = 0; i < tope_niveles; i++){
        int tope_camino = niveles[i].tope_camino;
        int tope_herramientas = 0;
        for (int j = 0; j < 5; j++){
            int posicion_camino = numero_aleatorio(1, tope_camino-2); // -2 por que en el tope no hay nada, y ultima es el altar
            int fil_totem = niveles[i].camino[posicion_camino].fil;
            int col_totem = niveles[i].camino[posicion_camino].col;

            while (es_posicion_pergamino(niveles[i].pergamino, fil_totem, col_totem)){
                posicion_camino = numero_aleatorio(1, tope_camino-2); // -2 por que en el tope no hay nada, y ultima es el altar
                fil_totem = niveles[i].camino[posicion_camino].fil;
                col_totem = niveles[i].camino[posicion_camino].col;
            }

            niveles[i].herramientas[j].tipo = TOTEM; //existen 3 herramientas echizo, totems, antorchas
            niveles[i].herramientas[j].posicion.fil = fil_totem;
            niveles[i].herramientas[j].posicion.col = col_totem;
            tope_herramientas++;
        }
        niveles[i].tope_herramientas = tope_herramientas;
    }
}

/*
* Pre condiciones: nivel debe ser inicializado. fila debe estar entre(0-19), columna debe estar entre (0-29).
* Post condiciones: devuelve true si la fila, columna coincide con una posicion de la herramienta (fila, columna). False en caso contrario
*/
bool es_posicion_herramienta(objeto_t herramienta[], int tope_herramientas, int fila, int columna){
    
    bool en_herramienta = false;
    int posicion_herramienta = 0;
    while(!en_herramienta && posicion_herramienta < tope_herramientas){

        if(herramienta[posicion_herramienta].posicion.fil == fila && herramienta[posicion_herramienta].posicion.col == columna){
            en_herramienta = true;
        } else {
            posicion_herramienta ++;
        }
    }
    return en_herramienta;
}

/*
* Pre condiciones: 'cantidad_obstaculos' debera ser un numero entero no negativo, 'tope' sebe ser 0, 
* Post condiciones: Inicializa una 10 piedras en posicion aleatoria(perteneciente al camino) sin superponer a otro objeto por cada uno de los tres niveles, carga el tope de los obstaculos por nivel.
*/
void inicializar_piedras_castigo(nivel_t niveles[MAX_NIVELES], int cantidad_obstaculos_nivel, int tope_niveles){
   //   niveles[i].tope_obstaculos = cantidad_obstaculos;

    for (int i = 0; i < tope_niveles; i++){
        int tope_obstaculos = 0;
        int tope_camino = niveles[i].tope_camino;

        for (int j = 0; j < cantidad_obstaculos_nivel; j++){
            int posicion_camino =  numero_aleatorio(1, (tope_camino-2));
            
            // asigno la fila, columna del camino a la piedra
            int fil_piedra = niveles[i].camino[posicion_camino].fil;
            int col_piedra = niveles[i].camino[posicion_camino].col;

            while (es_posicion_pergamino(niveles[i].pergamino, fil_piedra, col_piedra) && es_posicion_herramienta(niveles[i].herramientas, niveles[i].tope_herramientas, fil_piedra, col_piedra)){
                posicion_camino = numero_aleatorio(1, tope_camino-2);
                fil_piedra = niveles[i].camino[posicion_camino].fil;
                col_piedra = niveles[i].camino[posicion_camino].col;
            }

            niveles[i].obstaculos[j].tipo = PIEDRA_CASTIGO;
            // asigno a la piedra la fila y columna 
            niveles[i].obstaculos[j].posicion.fil = fil_piedra;
            niveles[i].obstaculos[j].posicion.col = col_piedra;
            tope_obstaculos ++;
        }

        niveles[i].tope_obstaculos = tope_obstaculos;
        
    }
}

/*
* Pre condiciones: nivel debe ser inicializado, tope_paredes debe ser un entero < 0 , fila debe estar entre(0-19), columna debe estar entre (0-29).
* Post condiciones: devuelve true si la fila, columna coincide con una posicion de la herramienta (fila, columna). False en caso contrario
*/
bool es_posicion_pared(nivel_t nivel, int tope_paredes, int fila, int columna){
    bool en_pared = false;
    int posicion_pared = 0;

    while(!en_pared && posicion_pared < tope_paredes){
        if(nivel.paredes[posicion_pared].fil == fila && nivel.paredes[posicion_pared].col == columna){
            en_pared = true;
        } else {
            posicion_pared ++;
        }
    }
    return en_pared;
}

/*
* Pre condiciones: -
* Post condiciones: Inicializa la posicion de una catapulta por nivel, la posicion no pertenece a una posicion del camino y distinto de la posicion de una pared. 
*/
void inicializar_catapultas(nivel_t niveles[MAX_NIVELES], int tope_niveles){
    
    for(int i = 0; i < tope_niveles; i++){
        int tope_obstaculos = niveles[i].tope_obstaculos;
        int fil_catapulta = numero_aleatorio(0, MAX_FILAS-1);
        int col_catapulta = numero_aleatorio(0, MAX_COLUMNAS-1);

        while (es_posicion_camino(niveles[i].camino, niveles[i].tope_camino, fil_catapulta, col_catapulta) || es_posicion_pared(niveles[i], niveles[i].tope_paredes, fil_catapulta, col_catapulta)){
            fil_catapulta = numero_aleatorio(0, MAX_FILAS-1);
            col_catapulta = numero_aleatorio(0, MAX_COLUMNAS-1);
        }
        niveles[i].obstaculos[tope_obstaculos].posicion.fil = fil_catapulta;
        niveles[i].obstaculos[tope_obstaculos].posicion.fil = col_catapulta;
        niveles[i].obstaculos[tope_obstaculos].tipo = CATAPULTA;

        tope_obstaculos ++;
        niveles[i].tope_obstaculos ++;
    }
}

/*
* Pre condiciones: -
* Post condciones: carga PIEDRA DEL CASTIGO, CATAPULCA FALTA HACERRRRR!!!!!!!!!!!!!!!!!!
*/
void inicializar_obstaculos(nivel_t niveles[MAX_NIVELES], int tope_niveles){

    int cantidad_obstaculos_nivel = 10;
    // piedra del catigo (10 en cada nivel de manera aleatoria)
    //   niveles[i].tope_obstaculos = cantidad_obstaculos;
    inicializar_piedras_castigo(niveles, cantidad_obstaculos_nivel, tope_niveles);

    inicializar_catapultas(niveles, tope_niveles);
}


/////////////////////////////////////////////////////////
void inicializar_juego(juego_t* juego) {

    /*
    Paredes
    Caminos
    Homero
    Runa
    Altar
    Pergaminoj
    Herramientas
    Obstáculos
    */
    int tope_niveles = 3;
    int nivel_actual = 0;

    (*juego).nivel_actual = nivel_actual;
    (*juego).tope_niveles = tope_niveles;
    (*juego).camino_visible = true;

   //crea paredes y camino para cada nivel
    inicializar_estructura( (*juego).niveles);

    //crea Homero posicion inicial
    inicializar_homero( &(*juego).homero, (*juego).niveles[0].camino[0]);

    //crear los items (runa, altar, pergamino)
    inicializar_pergaminos( (*juego).niveles );

    // crea hechizoz, antorchas y totems
    inicializar_herramientas( (*juego).niveles);

    // crea piedra castigo y catapulta
    inicializar_obstaculos((*juego).niveles, (*juego).tope_niveles);

    
}
//////////////////////////////////////////////////////////





///////////////////////////////////////////////
void cambiar_nivel(juego_t* juego) {    
    // primer nivel 1 despues 2 como cambio al tres
    (*juego).nivel_actual += 1;
}
//////////////////////////////////////////////////




/*
* Pre condiciones: -
* Post condicones: devuelve true si el movimiento es S, D, A ó W, False en caso contrario
*/
bool es_movimiento(char movimiento){
    return (movimiento == DERECHA || movimiento == ABAJO || movimiento == IZQUIERDA || movimiento == ARRIBA );
}

/*
* Pre condicones: -
* Post condiciones: devuelve true si el 'moviento' es H ó L. False en caso contrario. 
*/
bool es_herramienta(char movimiento){
    return (movimiento == HECHIZO_REVELADOR || movimiento == ANTORCHA);
}

/*
* Pre condiciones: -
* Post condiciones: carga el valor del movimiento (fil_movimiento, col_movimiento) realizado.  
*/
void valorar_movimiento(char movimiento, int* fil_movimiento, int* col_movimiento){
    switch (movimiento){
        case 'W':
            (*fil_movimiento) = -1;
            break;
        case 'S':
            (*fil_movimiento) = +1;
            break;
        case 'A':
            (*col_movimiento) = -1;
            break;
        case 'D':
            (*col_movimiento) = +1;
            break;   
        default:
            break;
    }
}

/*
* Pre condiciones: -
* Post condiciones: carga la posicion del personaje
*/
void posicionar_personaje(coordenada_t* coordenada, int fil_movimiento, int col_movimiento){
    (*coordenada).fil += fil_movimiento;
    (*coordenada).col += col_movimiento;
}

/*
* Pre condiciones: -
* Post condiciones: carga la posicion del pergamino.
*/
void llevar_pergamino(coordenada_t* coordenada, int fil_movimiento, int col_movimiento){
    (*coordenada).fil += fil_movimiento;
    (*coordenada).col += col_movimiento;
}

/*
* Pre condiciones: herramientas debe estar inicializado, fil_movimiento debe estar entre (0-19) y col_movimiento debe estar entre (0-29)  
* Post condiciones: devuelve el indice de la posicion en la que se encuentra la herramienta.
*/
int busca_posicion_herramienta(objeto_t herramientas[], int tope_herramientas, int fil_movimiento, int col_movimiento){
    int posicion = 0;
    bool posicion_encontrada = false;
    
    while(!posicion_encontrada && posicion < tope_herramientas){

        if (herramientas[posicion].posicion.fil == fil_movimiento && herramientas[posicion].posicion.col == col_movimiento){
            posicion_encontrada = true;
        } else {
            posicion ++;
        }
    }
    return posicion;
}

/*
* Pre condiciones: objeto debe estar inicializado.
* Post condiciones: incrementa una vida al personaje 
*/
void tomar_herramienta(int *vidas_restantes, objeto_t objeto){
    if (objeto.tipo == TOTEM){
        (*vidas_restantes) ++;
    }
}

/*
* Pre condiciones: herramientas debe estar inicializado, fil_movimiento debe estar entre (0-19) y col_movimiento debe estar entre (0-29)  
* Post condiciones: actualiza un vector de herramientas, actualiza el tope de herramientas.
*/
void eliminar_herramienta(objeto_t herramientas[], int* tope_herramientas, int posicion_herramienta){
    for (int i = posicion_herramienta; i < (*tope_herramientas)-1 ; i++){
        herramientas[i].tipo = herramientas[i+1].tipo;
        herramientas[i].posicion.fil = herramientas[i+1].posicion.fil;
        herramientas[i].posicion.col = herramientas[i+1].posicion.col;
    }
    (*tope_herramientas) -= 1;
}

/*
* Pre condiciones: coordenada debe estar inicializado, fil_movimiento debe estar entre (0-19) y col_movimiento debe estar entre (0-29)  
* Post condiciones: devuelve true si la posicion del personaje es igual a la posicion de la runa.
*/
bool es_runa(coordenada_t coordenada, int fil_personaje, int col_personaje){
    return (coordenada.fil == fil_personaje && coordenada.col == col_personaje);
}

/*
* Pre condiciones: coordenada debe estar inicializado, fil_movimiento debe estar entre (0-19) y col_movimiento debe estar entre (0-29)  
* Post condiciones: devuelve el indice de la posicion en la que se encuentra el camino.
*/
int busca_posicion_camino(coordenada_t coordenada[], int tope_caminos, int fil_camino, int col_camino){
    int posicion = 0;
    bool posicion_encontrada = false;
    
    while(!posicion_encontrada && posicion < tope_caminos){

        if (coordenada[posicion].fil == fil_camino && coordenada[posicion].col == col_camino){
            posicion_encontrada = true;
        } else {
            posicion ++;
        }
    }
    return posicion;
}

/*
* Pre condiciones: coordenada debe estar inicializado.
* Post condiciones: actualiza un vector de camino, actualiza el tope de camino.
*/
void eliminar_camino(coordenada_t coordenada[], int* tope_caminos, int posicion_camino){
    for (int i = posicion_camino; i < (*tope_caminos)-1 ; i++){
        coordenada[i].fil = coordenada[i+1].fil;
        coordenada[i].col = coordenada[i+1].col;
    }
    (*tope_caminos) -= 1;
}

/*
* Pre condiciones: nivel debe estar inicializado.
* Post condiciones: actualiza el vector de caminos(elimina el camino)
*/
void lanzar_bola_fuego(nivel_t* nivel, int* tope_caminos){
    int posicion_camino = numero_aleatorio(0, (*tope_caminos)-1);

    int fil_camino = (*nivel).camino[posicion_camino].fil;
    int col_camino = (*nivel).camino[posicion_camino].col;

    while (es_posicion_herramienta((*nivel).herramientas, (*nivel).tope_herramientas, fil_camino, col_camino) || es_posicion_pergamino((*nivel).pergamino, fil_camino, col_camino)){
        posicion_camino = numero_aleatorio(0, (*tope_caminos)-1);

        fil_camino = (*nivel).camino[posicion_camino].fil;
        col_camino = (*nivel).camino[posicion_camino].col;
    }

    int indice_posicion_camino;
    indice_posicion_camino = busca_posicion_camino((*nivel).camino, (*nivel).tope_camino, fil_camino, col_camino); ///!!!!!!!!!!!!!!!!
    eliminar_camino((*nivel).camino, &(*nivel).tope_camino, indice_posicion_camino);/////////!!!!!!!!!
}

/* REUTILIZABLE CON HERRAMIENTAS
* Pre condiciones: 
* Post condiciones:
*/
bool es_posicion_piedra_castigo (objeto_t obstaculo[], int tope_obstaculos, int fila, int columna){
    
    bool en_obstaculo = false;
    int posicion_obstaculo = 0;
    while(!en_obstaculo && posicion_obstaculo < tope_obstaculos){

        if(obstaculo[posicion_obstaculo].posicion.fil == fila && obstaculo[posicion_obstaculo].posicion.col == columna){
            en_obstaculo = true;
        } else {
            posicion_obstaculo ++;
        }
    }
    return en_obstaculo;
}

void posicionar_pergamino(nivel_t nivel, coordenada_t* posicion_pergamino, int tope_camino, coordenada_t camino[]){
    
    int posicion_camino = numero_aleatorio(1, (tope_camino-2));

    int fil_pergamino = camino[posicion_camino].fil;
    int col_pergamino = camino[posicion_camino].col;
    while (es_posicion_herramienta(nivel.herramientas, nivel.tope_herramientas, fil_pergamino, col_pergamino) || es_posicion_piedra_castigo(nivel.obstaculos, nivel.tope_obstaculos, fil_pergamino, col_pergamino)){
        posicion_camino = numero_aleatorio(1, (tope_camino-2));
    
        fil_pergamino = camino[posicion_camino].fil;
        col_pergamino = camino[posicion_camino].col;
    }

    (*posicion_pergamino).fil = fil_pergamino;
    (*posicion_pergamino).col = col_pergamino;


}

/*
* Pre condiciones: juego debe ser inicializado, movimiento tiene que ser A,S,D o W
* Post condciciones: guarda la nueva posicion del jugador si el movimiento es la posicion de un camino
*/
void dirigir_movimiento(juego_t *juego, int fil_movimiento, int col_movimiento){
    int nivel_actual = (*juego).nivel_actual;

    int fil_personaje = (*juego).homero.posicion.fil;
    int col_personaje = (*juego).homero.posicion.col;

    // verifica que la posicion + movimiento sea un camino
    if (es_posicion_camino((*juego).niveles[nivel_actual].camino, (*juego).niveles[nivel_actual].tope_camino, fil_personaje+fil_movimiento, col_personaje+col_movimiento)){
        posicionar_personaje(&(*juego).homero.posicion, fil_movimiento, col_movimiento);

        // si el movimiento es el pergamino lo lleva con el
        if (es_posicion_pergamino((*juego).niveles[nivel_actual].pergamino, fil_personaje, col_personaje)){
            llevar_pergamino(&(*juego).niveles[nivel_actual].pergamino, fil_movimiento, col_movimiento);
        }
        //  herramienta 
        
        if (es_posicion_herramienta((*juego).niveles[nivel_actual].herramientas, (*juego).niveles[nivel_actual].tope_herramientas, fil_personaje+fil_movimiento, col_personaje+col_movimiento)){
            //tomar_herramienta
            int indice_posic_herramienta;
            indice_posic_herramienta = busca_posicion_herramienta((*juego).niveles[nivel_actual].herramientas,(*juego).niveles[nivel_actual].tope_herramientas, fil_personaje+fil_movimiento, col_personaje+col_movimiento);
            tomar_herramienta(&(*juego).homero.vidas_restantes, (*juego).niveles[nivel_actual].herramientas[indice_posic_herramienta]);
            eliminar_herramienta((*juego).niveles[nivel_actual].herramientas, &(*juego).niveles[nivel_actual].tope_herramientas, indice_posic_herramienta);
        }

        // lanzar bola de fuego
        if (es_runa((*juego).niveles[nivel_actual].camino[0], fil_personaje+fil_movimiento, col_personaje+col_movimiento)){
            //si homero pisa la tuna lanzar una bola de juegos
            lanzar_bola_fuego(&(*juego).niveles[nivel_actual], &(*juego).niveles[nivel_actual].tope_camino);
        }

        // si es piedra del catigo R coloca de manera aleatoria el pergamino
        if (es_posicion_piedra_castigo((*juego).niveles[nivel_actual].obstaculos, (*juego).niveles[nivel_actual].tope_obstaculos, fil_personaje+fil_movimiento, col_personaje+col_movimiento)){
            int indice_posic_obstaculo;
            indice_posic_obstaculo = busca_posicion_herramienta((*juego).niveles[nivel_actual].obstaculos, (*juego).niveles[nivel_actual].tope_obstaculos, fil_personaje+fil_movimiento, col_personaje+col_movimiento);
        //    romper_obstaculo(&(*juego).niveles[nivel_actual].pergamino ,(*juego).niveles[nivel_actual].obstaculos[indice_posic_obstaculo]);
            posicionar_pergamino((*juego).niveles[nivel_actual], &(*juego).niveles[nivel_actual].pergamino, (*juego).niveles[nivel_actual].tope_camino, (*juego).niveles[nivel_actual].camino );
            eliminar_herramienta((*juego).niveles[nivel_actual].obstaculos, &(*juego).niveles[nivel_actual].tope_obstaculos, indice_posic_obstaculo);
        }
    
    } else if (es_posicion_pared((*juego).niveles[nivel_actual], (*juego).niveles[nivel_actual].tope_paredes, fil_personaje+fil_movimiento, col_personaje+col_movimiento)){
        printf("--- TE CHOCASTE CON UNA PARED ---");

    } else {
        (*juego).homero.vidas_restantes -=1;
    
    }

    //if ((*juego).homero.posicion.fil == (*juego).niveles[nivel_actual].camino[0].fil && (*juego).homero.posicion.col == (*juego).niveles[nivel_actual].camino[0].col ){
    if (es_runa((*juego).niveles[nivel_actual].camino[0], fil_personaje+fil_movimiento, col_personaje+col_movimiento)){
        (*juego).camino_visible = true;

    } else {
        (*juego).camino_visible = false;
        (*juego).homero.antorcha_encendida = false;
    
    }


    // no pertenece al camino ni a las paredes
    // el movimiento no pertenece al camino resta una vida
}


//////////////////////////////////////////////////
void realizar_jugada(juego_t* juego, char movimiento){
    int fil_movimiento = 0;
    int col_movimiento = 0;
    int nivel_actual = (*juego).nivel_actual;
    //realiza el pre-movimiento
    if (es_movimiento(movimiento)){
        valorar_movimiento(movimiento, &fil_movimiento, &col_movimiento);
        dirigir_movimiento(&(*juego), fil_movimiento, col_movimiento);

    } else if (es_herramienta(movimiento)){
        /// H para hechizos

        //SI LANZA HECHIZO ACTIVA CATAPULTA
        if ((movimiento == HECHIZO_REVELADOR) && ((*juego).homero.hechizos_reveladores > 0) ){
            (*juego).camino_visible = true;
            (*juego).homero.hechizos_reveladores -= 1;
            lanzar_bola_fuego(&(*juego).niveles[nivel_actual], &(*juego).niveles[nivel_actual].tope_camino);
        } 

        if ((movimiento == ANTORCHA) && ((*juego).homero.antorchas > 0)){
            (*juego).homero.antorcha_encendida = true;
            (*juego).homero.antorchas -= 1;
        }
        // L para antorcha

    }
}
////////////////////////////////////////////////////




void mostrar_bienvenida(){
    system("clear");
    printf("%s\n", MSJ_BIENVENIDA);
}

/*
* Pre condiciones: mapa debe estar inicializado
* Post condiciones: carga paredes al mapa.
*/
void agregar_paredes(char mapa[MAX_FILAS][MAX_COLUMNAS], coordenada_t paredes[MAX_PAREDES], int tope_paredes){
    //agregar paredes
    for (int i = 0; i < tope_paredes; i++){
        int fil_pared = paredes[i].fil;
        int col_pared = paredes[i].col;
        mapa[fil_pared][col_pared] = PARED;
    }
}

/*
* Pre condiciones: mapa debe ser inicializado
* Post condiciones: agrega camino al mapa.
*/
void agregar_camino(char mapa[MAX_FILAS][MAX_COLUMNAS], coordenada_t camino[MAX_CAMINO], int tope_camino){
    //agregar camino
    for (int i = 0; i < tope_camino; i++){
        int fil_camino = camino[i].fil;
        int col_camino = camino[i].col;

        mapa[fil_camino][col_camino] = CAMINO;
    }
}


void agregar_camino_manhattan(char mapa[MAX_FILAS][MAX_COLUMNAS], coordenada_t camino[MAX_CAMINO], int tope_camino, coordenada_t posicion){
    int fil_homero = posicion.fil;
    int col_homero = posicion.col;
    int rango = 3;

    // H(0,0) --> M(1,2)
    for (int i = 0; i < tope_camino; i++){

        if(((fil_homero - camino[i].fil) <= rango) && ((col_homero - camino[i].col <= rango)) ){
            
            if(((fil_homero - camino[i].fil) >= -rango) && ((col_homero - camino[i].col >= -rango))){
                int fil_coordenada = fil_homero - camino[i].fil;
                int col_coordenada = col_homero - camino[i].col;
            
                if ((fil_coordenada + col_coordenada) <= rango && (fil_coordenada - col_coordenada) >= -rango ){

                    if ((fil_coordenada - col_coordenada) <= rango && (fil_coordenada + col_coordenada) >= -rango ){

                        mapa[camino[i].fil][camino[i].col] = CAMINO;
                    }
                }                    
            } 
        } 

        /*
        if((fil_homero +1 == camino[i].fil) && (col_homero == camino[i].col)){
            mapa[camino[i].fil][camino[i].col] = CAMINO;
        }
        
        if((fil_homero == camino[i].fil) && (col_homero +1 == camino[i].col)){
            mapa[camino[i].fil][camino[i].col] = CAMINO;
        }
        
        if((fil_homero -1 == camino[i].fil) && (col_homero == camino[i].col)){
            mapa[camino[i].fil][camino[i].col] = CAMINO;
        }
        
        if( (fil_homero == camino[i].fil) && (col_homero -1 == camino[i].col)){
            mapa[camino[i].fil][camino[i].col] = CAMINO;
        }
        */
    }
}

/*
* Pre condiciones: mapa debe ser inicializado
* Post condiciones: agrega el peronaje al mapa.
*/
void agregar_personaje(char mapa[MAX_FILAS][MAX_COLUMNAS], personaje_t homero){
    int fil_homero = homero.posicion.fil;
    int col_homero = homero.posicion.col;

    mapa[fil_homero][col_homero] = HOMERO;
}



/*
* Pre condiciones: mapa, juego debe estar inicializado
* Post condicones: carga la runa, altar, pergamino en el mapa 
*/
void agregar_items(char mapa[MAX_FILAS][MAX_COLUMNAS], nivel_t niveles[], int nivel_actual){
    // Runa (donde se encuntra homero)
    int tope_camino = niveles[nivel_actual].tope_camino;

    int camino_inicial_fil = niveles[nivel_actual].camino[0].fil;
    int camino_inicial_col = niveles[nivel_actual].camino[0].col;

    mapa [camino_inicial_fil][camino_inicial_col] = RUNA;

    // altar (en la ultima posicion del camino)
    int camino_final_fil = niveles[nivel_actual].camino[tope_camino-1].fil;
    int camino_final_col = niveles[nivel_actual].camino[tope_camino-1].col;

    mapa [camino_final_fil][camino_final_col] = ALTAR;

    // pergamino esta en posicion ramdom
    int fil_pergamino = niveles[nivel_actual].pergamino.fil;
    int col_pergamino = niveles[nivel_actual].pergamino.col;

    mapa [fil_pergamino][col_pergamino] = PERGAMINO;
}

/*
* Pre condiciones: mapa, juego deben estar inicializados
* Post condiciones: FALTA HACERRRRRR!!!!!!!!!!!!!!!!!
*/
void agregar_obstaculos(char mapa[MAX_FILAS][MAX_COLUMNAS], nivel_t niveles[], int nivel_actual, int tope_obstaculos){
    // piedras
    for (int i = 0; i < tope_obstaculos; i++){
        int piedra_fil = niveles[nivel_actual].obstaculos[i].posicion.fil;
        int piedra_col = niveles[nivel_actual].obstaculos[i].posicion.col; 
        if (niveles[nivel_actual].obstaculos[i].tipo == PIEDRA_CASTIGO){
            mapa[piedra_fil][piedra_col] = PIEDRA_CASTIGO; 
        } else if (niveles[nivel_actual].obstaculos[i].tipo == CATAPULTA) {
            mapa[piedra_fil][piedra_col] = CATAPULTA;
        }
    }
}

/*
* Pre condiciones: mapa, juego deben estar inicializados
* Post condiciones: FALTA HACERRRRRR!!!!!!!!!!!!!!!!!
*/
void agregar_herramientas(char mapa[MAX_FILAS][MAX_COLUMNAS], nivel_t niveles[], int nivel_actual, int tope_herramientas){
    
    // Totems
    for (int i = 0; i < tope_herramientas; i++){
        int totem_fil = niveles[nivel_actual].herramientas[i].posicion.fil;
        int totem_col = niveles[nivel_actual].herramientas[i].posicion.col;
        mapa[totem_fil][totem_col] = TOTEM; /////AREGLAR
    }
}



/*
* Pre condiciones: mapa, juego deben estar inicializados
* Post condiciones: crea un mapa del juego
*/
void crear_mapa(char mapa[MAX_FILAS][MAX_COLUMNAS], juego_t juego){
    int nivel_actual = juego.nivel_actual;
    
    for (int i = 0; i < MAX_FILAS; i++){
        for(int j = 0; j < MAX_COLUMNAS; j++){
            mapa[i][j] = VACIO;
        }
    }
  
    agregar_paredes(mapa, juego.niveles[nivel_actual].paredes, juego.niveles[nivel_actual].tope_paredes);

    if (juego.camino_visible){
        agregar_camino(mapa, juego.niveles[nivel_actual].camino, juego.niveles[nivel_actual].tope_camino);

    } else if (juego.homero.antorcha_encendida){
        agregar_camino_manhattan(mapa, juego.niveles[nivel_actual].camino, juego.niveles[nivel_actual].tope_camino, juego.homero.posicion);
    }

    agregar_personaje(mapa, juego.homero);
    
    /// agregar items (Runa, altar, pergamino)
    agregar_items(mapa, juego.niveles, juego.nivel_actual);

    /// agregar obtaculos pidra castigo, obstaculos
    agregar_obstaculos(mapa, juego.niveles, nivel_actual, juego.niveles[nivel_actual].tope_obstaculos);

    // agrega totem
    agregar_herramientas (mapa,juego.niveles, nivel_actual, juego.niveles[nivel_actual].tope_herramientas);
}

///////////////////////////////////////////////
int estado_nivel(nivel_t nivel, personaje_t homero){
    // nivel  ganado si el pergamino+homero esta en el altar 0= jugando, 1 ganado utilizar personaje _t!!!!
    int tope = nivel.tope_camino;

    int altar_fil = nivel.camino[tope-1].fil;
    int altar_col = nivel.camino[tope-1].col;

    int pergamino_fil = nivel.pergamino.fil;
    int pergamino_col = nivel.pergamino.col;

    if (pergamino_fil == altar_fil && pergamino_col == altar_col){
        return 1;
    } else {
        return 0;
    }
}
/////////////////////////////////////////////////

//////////////////////////////////////////////////
int estado_juego(juego_t juego){
  //  int ganado = 1;
    int perdido = -1;
    int jugando = 0;
//    int tope = juego.niveles[2].tope_camino -1;
//    int nivel_final = juego.niveles[3].camino[tope].fil;
//    int nivel_finnal = juego.niveles[3].camino[tope].col;
    int vidas = juego.homero.vidas_restantes;

    if (vidas == 0){
        return perdido;
    } else {
        return jugando;
    }

}
////////////////////////////////////////////////////

/*
* Pre condicones: mapa debe ser inicializado 
* Post condiciones: muestra por pantalla el mapa del juego
*/
void mostrar_mapa(char mapa[MAX_FILAS][MAX_COLUMNAS]){
    //imprimir matriz
    for (int i = 0; i < MAX_FILAS; i++){
        for(int j = 0; j < MAX_COLUMNAS; j++){
            printf("%c ", mapa[i][j]);
        }
        printf("\n");
    }
}

void mostrar_menu (int numero_vidas, int numero_hechizos, int numero_antorchas){
    printf("-----------------------------------------------------------\n\n");
    printf("Vidas: %i             \nHechizo revelador: %i              presionar (H) para utilizar\nAntorchas: %i                     presionar (L) para utilizar\n\n", numero_vidas, numero_hechizos, numero_antorchas);
}
/////////////////////////////////////////////////////////////////////
/*
void mostrar_juego(juego_t juego){

    char mapa[MAX_FILAS][MAX_COLUMNAS];
    int nivel = juego.nivel_actual;
    
    // el juego se mantiene mientras el estado del juego sea jugando y el nivel sea menor a 3
    while ((estado_juego(juego) == 0) && ( nivel < 3)){
        int numero_vidas = juego.homero.vidas_restantes;
        int numero_hechizos = juego.homero.hechizos_reveladores;
        int numero_antorchas = juego.homero.antorchas;
        
        char movimiento = ' ';
        
        crear_mapa(mapa, juego);
        
        mostrar_bienvenida();
        mostrar_mapa(mapa);

        pedir_movimiento(&movimiento, numero_vidas, numero_hechizos, numero_antorchas);
        realizar_jugada(&juego, movimiento);

        if (estado_nivel((juego).niveles[nivel]) == 1){
            cambiar_nivel(&(juego));
            nivel = juego.nivel_actual;
            juego.camino_visible = true;
        }
    }  
    if (estado_juego(juego) == -1){
        system("clear");
        printf("%s", MSJ_ELIMINACION);
    } else {
        system("clear");
        printf("%s", MSJ_JUEGO_GANADO);
    }
}
*/
//////////////////////////////////////////////////////////////////////////////
void mostrar_juego(juego_t juego){
    char mapa[MAX_FILAS][MAX_COLUMNAS];
    int numero_vidas = juego.homero.vidas_restantes;
    int numero_hechizos = juego.homero.hechizos_reveladores;
    int numero_antorchas = juego.homero.antorchas;

    crear_mapa (mapa, juego);
    mostrar_bienvenida();
    mostrar_mapa(mapa);
    mostrar_menu(numero_vidas, numero_hechizos, numero_antorchas);
}